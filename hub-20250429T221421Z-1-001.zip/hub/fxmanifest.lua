fx_version 'cerulean'
game 'gta5'

author 'LUCKY'
description 'Server Hub UI for FiveM'
version '1.0.0'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}