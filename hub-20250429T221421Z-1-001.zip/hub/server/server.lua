-- Placeholder for any server-side logic
print("Server script loaded!")